package id.dwichan.githubusers.userList

class UserItems(
    var login: String? = null,
    var name: String? = null,
    var avatar: String? = null,
    var public_repos: Int = 0
)